% @RAWDATA
%
% Files
%   display - Command window display of a rawData
%   eq      - Compares two objects.
%   get     - DEPRECATED. Get properties from the specified object
%   rawData - Abstract Class rawData
%   set     - DEPRECATED. Set object properties and return the updated object
