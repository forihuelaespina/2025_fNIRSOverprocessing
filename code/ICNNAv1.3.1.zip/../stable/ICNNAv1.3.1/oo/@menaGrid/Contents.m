% @MENAGRID
%
% Files
%   display  - MENAGRID/DISPLAY Command window display of a rawData
%   eq       - MENAGRID/EQ Compares two objects.
%   get      - MENAGRID/GET Get properties from the specified object
%   menaGrid - Abstract Class menaGrid
%   set      - MENAGRID/SET Set object properties and return the updated object
