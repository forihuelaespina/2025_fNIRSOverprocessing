% @NEUROIMAGE
%
% Files
%   display    - Command window display
%   eq         - Compares two objects.
%   neuroimage - Class neuroimage
%   get        - DEPRECATED. Get properties from the specified object
%   set        - DEPRECATED. Set object properties and return the updated object
%