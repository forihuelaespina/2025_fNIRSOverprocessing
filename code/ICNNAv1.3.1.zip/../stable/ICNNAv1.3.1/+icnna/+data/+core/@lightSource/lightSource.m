classdef lightSource
% icnna.data.core.lightSource - A light source or emitter
%
% Available since ICNNA v1.3.1
%
% A light source or emitter.
%
%
% Somewhat loosely inspired by MCX "src" component.
%
%% Light sources
%
% Together with icnna.data.core.lightDetector they form the optode
% pairs forming a channel.
%
%
