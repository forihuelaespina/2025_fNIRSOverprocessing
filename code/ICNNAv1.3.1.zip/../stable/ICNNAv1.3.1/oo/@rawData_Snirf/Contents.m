% @RAWDATA_SNIRF
%
% Files
%   convert         - Convert raw light intensities to a neuroimage
%   display         - Command window display of a rawData_Snirf
%   eq              - Compares two objects.
%   import          - Reads the raw light intensities 
%   export          - Write an snirf file (content may be light intensities or concentrations
%   rawData_Snirf   - Class rawData_Snirf
%